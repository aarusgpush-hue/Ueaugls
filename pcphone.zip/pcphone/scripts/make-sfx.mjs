// Synthesizes original, copyright-free SFX -> public/sfx/*.wav (16-bit mono 44.1k)
import { writeFileSync, mkdirSync } from "node:fs";
const SR = 44100;
mkdirSync("public/sfx", { recursive: true });
const wav = (name, f) => {
  const arr = f(); const buf = Buffer.alloc(44 + arr.length * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + arr.length * 2, 4); buf.write("WAVEfmt ", 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(arr.length * 2, 40);
  arr.forEach((v, i) => buf.writeInt16LE(Math.max(-1, Math.min(1, v)) * 32767 | 0, 44 + i * 2));
  writeFileSync(`public/sfx/${name}.wav`, buf);
};
let seed = 1337; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647) * 2 - 1;
const mk = (sec, g) => Array.from({ length: Math.floor(SR * sec) }, (_, i) => g(i / SR, i / (SR * sec)));
wav("whoosh", () => { let y = 0; return mk(0.55, (t, u) => { y += (0.02 + 0.5 * Math.sin(Math.PI * u) ** 2) * (rnd() - y); return y * Math.sin(Math.PI * u) ** 1.5 * 1.6; }); });
wav("pop", () => mk(0.16, (t, u) => Math.sin(2 * Math.PI * (150 + 450 * Math.exp(-t * 40)) * t) * Math.exp(-t * 24) * 0.9));
wav("thud", () => mk(0.45, (t) => Math.sin(2 * Math.PI * (40 + 70 * Math.exp(-t * 18)) * t) * Math.exp(-t * 9) * 0.95));
wav("tick", () => mk(0.04, (t) => Math.sin(2 * Math.PI * 2200 * t) * Math.exp(-t * 140) * 0.6));
wav("shimmer", () => mk(0.9, (t, u) => [880, 1320, 1760, 2640].reduce((a, f, i) => a + Math.sin(2 * Math.PI * f * t + i) * 0.16 * Math.exp(-t * (3 + i)), 0) * Math.min(1, t * 60)));
console.log("SFX generated");
