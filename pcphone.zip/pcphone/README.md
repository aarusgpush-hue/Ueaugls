npm install
npm run start     # Remotion Studio (localhost:3000), composition: Main
npm run render    # out/video.mp4
Optional: HAS_VOICEOVER=true in src/config.ts + public/voiceover.mp3
Timing constants for GTA / brand cards: top of scenes/Scene3.tsx, Scene6.tsx
