import React from "react";
import { AbsoluteFill, Audio, Sequence, spring, staticFile, interpolate } from "remotion";
import { BgMesh, Grade, Grain, Vignette } from "./components/Layers";
import { Sfx, useT, clamp01 } from "./components/Motion";
import { HAS_VOICEOVER, SHOW_CAPTIONS, FPS, TOTAL_FRAMES, cues, sceneStarts } from "./config";
import { theme, glass } from "./theme";
import { Scene1 } from "./scenes/Scene1";
import { Scene2 } from "./scenes/Scene2";
import { Scene3 } from "./scenes/Scene3";
import { Scene4 } from "./scenes/Scene4";
import { Scene5 } from "./scenes/Scene5";
import { Scene6 } from "./scenes/Scene6";

const scenes = [Scene1, Scene2, Scene3, Scene4, Scene5, Scene6];
const startF = sceneStarts.map((x) => x * FPS);

const Wipe: React.FC = () => {
  const { frame, dur } = useT();
  const t = interpolate(frame, [0, dur], [0, 1], { easing: theme.ease.inOut });
  return (
    <AbsoluteFill style={{ pointerEvents: "none", overflow: "hidden" }}>
      <div style={{
        position: "absolute", top: -200, bottom: -200, width: 2700, left: interpolate(t, [0, 1], [-2800, 2000]),
        transform: "skewX(-12deg)", filter: "blur(4px)",
        background: `linear-gradient(90deg, transparent, ${theme.colors.primary}EE 25%, ${theme.colors.bgAlt} 50%, ${theme.colors.primary}EE 75%, transparent)`,
      }} />
    </AbsoluteFill>
  );
};

const Caption: React.FC<{ text: string }> = ({ text }) => {
  const { frame, fps, dur } = useT();
  const p = spring({ frame, fps, config: theme.spring.smooth });
  const out = interpolate(frame, [dur - 8, dur - 1], [1, 0], { easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ justifyContent: "flex-end", alignItems: "center", paddingBottom: 60 }}>
      <div style={{
        ...glass, borderRadius: 999, padding: "16px 48px", maxWidth: 1560, textAlign: "center",
        fontFamily: theme.fonts.display, fontWeight: 600, fontSize: 42, lineHeight: 1.35, color: theme.colors.text,
        opacity: clamp01(p) * out, transform: `translateY(${interpolate(p, [0, 1], [24, 0])}px)`,
      }}>{text}</div>
    </AbsoluteFill>
  );
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{ background: theme.colors.bg }}>
    <BgMesh />
    {scenes.map((S, i) => {
      const end = i < scenes.length - 1 ? startF[i + 1] : TOTAL_FRAMES;
      return <Sequence key={i} from={startF[i]} durationInFrames={end - startF[i]}><S /></Sequence>;
    })}
    {startF.slice(1).map((b, i) => (
      <React.Fragment key={b}>
        <Sequence from={b - 8} durationInFrames={16}><Wipe /></Sequence>
        <Sfx at={b - 11} name="whoosh" vol={0.6} />
        <Sfx at={b - 1} name="thud" vol={0.45} />
      </React.Fragment>
    ))}
    {SHOW_CAPTIONS && cues.map((c, i) => (
      <Sequence key={i} from={c.start * FPS} durationInFrames={Math.max(1, (c.end - c.start) * FPS)}><Caption text={c.text} /></Sequence>
    ))}
    <Grade />
    <Grain />
    <Vignette />
    {HAS_VOICEOVER && <Audio src={staticFile("voiceover.mp3")} />}
  </AbsoluteFill>
);
