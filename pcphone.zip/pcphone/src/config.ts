// ---- Project settings (edit here) ----
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const TOTAL_SEC = 72;
export const TOTAL_FRAMES = TOTAL_SEC * FPS;

export const HAS_VOICEOVER = false; // true + put file at public/voiceover.mp3
export const SHOW_CAPTIONS = true; // Bengali captions from the SRT
export const SFX_ON = true; // synthesized, copyright-free (npm run sfx)

// Straight from the SRT (seconds)
export const cues = [
  { start: 0, end: 5, text: "আপনারা কনফিউজড হয়ে যান, ১ লাখ টাকার কম্পিউটার কিনবেন নাকি ১ লাখ টাকার ফোন।" },
  { start: 6, end: 13, text: "যদি গেমিং করতে চান, তাহলে আপনারা অবশ্যই একটা কম্পিউটার বা ল্যাপটপ কিনতে পারেন।" },
  { start: 14, end: 27, text: "ওটার মধ্যে সবথেকে হেভি গেম চলবে, যেমন GTA 5, GTA 6 এবং Call of Duty।" },
  { start: 28, end: 36, text: "কিন্তু এই জিনিসটা আপনারা ফোনে পাবেন না। ফোন হিট হয়ে যাবে বা সাপোর্ট করবে না।" },
  { start: 37, end: 50, text: "যদি আপনাদের পকেট ফ্রেন্ডলি বা ট্রাভেলিংয়ের জন্য দরকার হয়, তাহলে ল্যাপটপ বেস্ট।" },
  { start: 51, end: 72, text: "আর যদি ফোন কিনতেই হয়, তাহলে Samsung বা Google Pixel কিনতে পারেন।" },
];
// Each scene starts at its cue start; scene ends where the next begins.
export const sceneStarts = cues.map((c) => c.start);
