import { loadFont as loadBn } from "@remotion/google-fonts/HindSiliguri";
import { loadFont as loadLatin } from "@remotion/google-fonts/Inter";

export const bn = loadBn("normal", { weights: ["500", "600", "700"], subsets: ["bengali", "latin"] });
export const latin = loadLatin("normal", { weights: ["600", "800"], subsets: ["latin"] });
