// Single source of truth. Never inline colors / easings in components.
import { Easing } from "remotion";
import { bn, latin } from "./fonts";

export const theme = {
  colors: {
    bg: "#070B14",
    bgAlt: "#0D1426",
    primary: "#4F8CFF", // hero
    accent: "#22D3EE",
    warn: "#FF6B4A", // heat scene only
    text: "#F4F6FB",
    textDim: "#9AA6BD",
    glow: "rgba(79, 140, 255, 0.45)",
    card: "rgba(255,255,255,0.05)",
    line: "rgba(255,255,255,0.12)",
  },
  fonts: {
    display: `${bn.fontFamily}, ${latin.fontFamily}, sans-serif`, // Bengali + fallback
    latin: `${latin.fontFamily}, ${bn.fontFamily}, sans-serif`, // Brand / game names
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
} as const;

export const toBn = (n: number) =>
  Math.round(n).toLocaleString("en-IN").replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);

// Apple-style glass surface
export const glass: import("react").CSSProperties = {
  background: "linear-gradient(135deg, rgba(255,255,255,0.16), rgba(255,255,255,0.04))",
  backdropFilter: "blur(28px) saturate(180%)",
  WebkitBackdropFilter: "blur(28px) saturate(180%)",
  border: "1px solid rgba(255,255,255,0.22)",
  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.38), inset 0 -1px 0 rgba(255,255,255,0.06), 0 30px 80px -20px rgba(0,0,0,0.55)",
};
