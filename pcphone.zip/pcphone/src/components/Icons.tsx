import React from "react";
import { interpolateColors } from "remotion";
import { theme } from "../theme";

const body = "#0F172A", rim = "#94A3B8";

export const LaptopIcon: React.FC<{ width?: number; lit?: number; id?: string }> = ({ width = 560, lit = 1, id = "lp" }) => (
  <svg width={width} height={(width * 280) / 440} viewBox="0 0 440 280" style={{ overflow: "visible" }}>
    <defs>
      <linearGradient id={`${id}-s`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={theme.colors.primary} stopOpacity={0.25 + 0.6 * lit} />
        <stop offset="1" stopColor={theme.colors.accent} stopOpacity={0.1 + 0.45 * lit} />
      </linearGradient>
    </defs>
    <rect x="50" y="10" width="340" height="215" rx="18" fill={body} stroke={rim} strokeWidth="6" />
    <rect x="66" y="26" width="308" height="183" rx="8" fill={`url(#${id}-s)`} />
    {[0, 1, 2, 3].map((i) => (
      <rect key={i} x="90" y={52 + i * 34} width={140 + ((i * 53) % 90)} height="10" rx="5" fill="#fff" opacity={0.12 + 0.18 * lit} />
    ))}
    <path d="M10 235 H430 L405 262 Q400 270 390 270 H50 Q40 270 35 262 Z" fill="#1E293B" stroke={rim} strokeWidth="4" />
    <rect x="185" y="235" width="70" height="8" rx="4" fill={body} />
  </svg>
);

export const PhoneIcon: React.FC<{ height?: number; heat?: number; id?: string }> = ({ height = 420, heat = 0, id = "ph" }) => {
  const c1 = interpolateColors(heat, [0, 1], ["#1D4ED8", "#B91C1C"]);
  const c2 = interpolateColors(heat, [0, 1], [theme.colors.accent, theme.colors.warn]);
  return (
    <svg width={(height * 150) / 300} height={height} viewBox="0 0 150 300" style={{ overflow: "visible" }}>
      <defs>
        <linearGradient id={`${id}-s`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={c1} /><stop offset="1" stopColor={c2} stopOpacity={0.85} />
        </linearGradient>
      </defs>
      <rect x="6" y="6" width="138" height="288" rx="28" fill={body} stroke={rim} strokeWidth="5" />
      <rect x="16" y="16" width="118" height="268" rx="19" fill={`url(#${id}-s)`} />
      <circle cx="75" cy="33" r="5" fill={body} />
      {[0, 1, 2].map((i) => <rect key={i} x="32" y={80 + i * 30} width={60 + i * 12} height="9" rx="4.5" fill="#fff" opacity="0.22" />)}
    </svg>
  );
};

export const GamepadIcon: React.FC<{ width?: number }> = ({ width = 300 }) => (
  <svg width={width} height={(width * 150) / 260} viewBox="0 0 260 150" style={{ overflow: "visible" }}>
    <circle cx="62" cy="106" r="42" fill="#1E293B" /><circle cx="198" cy="106" r="42" fill="#1E293B" />
    <rect x="30" y="24" width="200" height="92" rx="44" fill="#1E293B" stroke={rim} strokeWidth="4" />
    <rect x="62" y="64" width="40" height="12" rx="5" fill={rim} /><rect x="76" y="50" width="12" height="40" rx="5" fill={rim} />
    {[[170, 54], [194, 72], [170, 90], [146, 72]].map(([x, y], i) => (
      <circle key={i} cx={x} cy={y} r="9" fill={i === 0 ? theme.colors.accent : "#475569"} />
    ))}
  </svg>
);

export const Check: React.FC<{ size?: number; progress?: number; color?: string }> = ({ size = 56, progress = 1, color = theme.colors.accent }) => (
  <svg width={size} height={size} viewBox="0 0 60 60">
    <circle cx="30" cy="30" r="27" fill="none" stroke={color} strokeWidth="3" opacity={0.35 + 0.65 * progress} />
    <path d="M17 31 L26 40 L43 20" fill="none" stroke={color} strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"
      strokeDasharray="50" strokeDashoffset={50 * (1 - progress)} />
  </svg>
);

export const Cross: React.FC<{ size?: number; progress?: number; color?: string }> = ({ size = 56, progress = 1, color = theme.colors.warn }) => (
  <svg width={size} height={size} viewBox="0 0 60 60">
    <circle cx="30" cy="30" r="27" fill="none" stroke={color} strokeWidth="3" opacity={0.35 + 0.65 * progress} />
    <path d="M19 19 L41 41 M41 19 L19 41" fill="none" stroke={color} strokeWidth="6" strokeLinecap="round"
      strokeDasharray="32" strokeDashoffset={32 * (1 - progress)} />
  </svg>
);
