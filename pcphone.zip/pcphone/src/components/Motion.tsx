import React from "react";
import { AbsoluteFill, Audio, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme, glass } from "../theme";
import { SFX_ON } from "../config";

export const useT = () => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  return { frame, fps, dur: durationInFrames, s: (sec: number) => Math.round(sec * fps) };
};

export const useFloat = (amp = 8, speed = 30, phase = 0) => {
  const { frame } = useT();
  return Math.sin((frame + phase) / speed) * amp;
};

export const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
export const ramp = (frame: number, a: number, b: number, easing = theme.ease.out) =>
  interpolate(frame, [a, b], [0, 1], { easing, extrapolateLeft: "clamp", extrapolateRight: "clamp" });

/** Fade + rise + scale, spring-driven. */
export const Entrance: React.FC<{
  delay?: number; x?: number; y?: number; from?: number; rotate?: number;
  preset?: keyof typeof theme.spring; style?: React.CSSProperties; children: React.ReactNode;
}> = ({ delay = 0, x = 0, y = 40, from = 0.94, rotate = 0, preset = "smooth", style, children }) => {
  const { frame, fps } = useT();
  const p = spring({ frame: frame - delay, fps, config: theme.spring[preset] });
  return (
    <div style={{
      opacity: clamp01(p),
      transform: `translate(${interpolate(p, [0, 1], [x, 0])}px, ${interpolate(p, [0, 1], [y, 0])}px) rotate(${interpolate(p, [0, 1], [rotate, 0])}deg) scale(${interpolate(p, [0, 1], [from, 1])})`,
      ...style,
    }}>{children}</div>
  );
};

/** Word-by-word reveal. Pixel gaps (not em). `hl` = indices shown in hero colour. */
export const WordReveal: React.FC<{
  text: string; delay?: number; per?: number; size?: number; hl?: number[]; align?: "center" | "flex-start";
  latin?: boolean; style?: React.CSSProperties;
}> = ({ text, delay = 0, per = 4, size = 120, hl = [], align = "center", latin = false, style }) => {
  const { frame, fps } = useT();
  return (
    <div style={{
      display: "flex", flexWrap: "wrap", justifyContent: align, columnGap: Math.round(size * 0.26), rowGap: 8,
      fontFamily: latin ? theme.fonts.latin : theme.fonts.display, fontWeight: 700, fontSize: size,
      lineHeight: 1.18, color: theme.colors.text, ...style,
    }}>
      {text.split(" ").map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        const hero = hl.includes(i);
        return (
          <span key={i} style={{
            display: "inline-block", opacity: clamp01(p),
            transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.92, 1])})`,
            color: hero ? theme.colors.primary : theme.colors.text,
            textShadow: hero ? `0 0 50px ${theme.colors.primary}88` : "none",
          }}>{w}</span>
        );
      })}
    </div>
  );
};

/** Hero pill that sweeps in behind a word. */
export const HeroWord: React.FC<{ delay?: number; size?: number; children: React.ReactNode }> = ({ delay = 0, size = 120, children }) => {
  const { frame, fps } = useT();
  const p = spring({ frame: frame - delay, fps, config: theme.spring.snappy });
  const w = ramp(frame, delay + 5, delay + 20);
  return (
    <span style={{
      position: "relative", display: "inline-block", padding: "0 34px", fontFamily: theme.fonts.display,
      fontWeight: 700, fontSize: size, lineHeight: 1.18, color: theme.colors.text, opacity: clamp01(p),
      transform: `translateY(${interpolate(p, [0, 1], [30, 0])}px)`,
    }}>
      <span style={{
        position: "absolute", inset: "8px 0", borderRadius: 28, background: theme.colors.primary,
        transformOrigin: "left center", transform: `scaleX(${w})`, boxShadow: `0 0 70px ${theme.colors.primary}66`,
      }} />
      <span style={{ position: "relative" }}>{children}</span>
    </span>
  );
};

export const Chip: React.FC<{ hero?: boolean; size?: number; children: React.ReactNode }> = ({ hero, size = 34, children }) => (
  <div style={{
    display: "inline-flex", alignItems: "center", gap: 12, padding: "10px 30px", borderRadius: 999,
    ...glass, ...(hero ? { border: `1.5px solid ${theme.colors.primary}`, background: `${theme.colors.primary}33` } : {}),
    color: theme.colors.text,
    fontFamily: theme.fonts.display, fontWeight: 600, fontSize: size,
  }}>{children}</div>
);

/** Scene wrapper: fast exit (10f) — shorter than entrances. */
export const SceneWrap: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { frame, dur } = useT();
  const t = interpolate(frame, [dur - 10, dur - 1], [0, 1], { easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <AbsoluteFill style={{ opacity: 1 - t, transform: `translateX(${-90 * t}px) scale(${1 + 0.03 * t})` }}>{children}</AbsoluteFill>
  );
};

/** Synthesized SFX; place 2–3 frames BEFORE the visual lands. */
export const Sfx: React.FC<{ at: number; name: "whoosh" | "pop" | "thud" | "tick" | "shimmer"; vol?: number }> = ({ at, name, vol = 0.55 }) => {
  if (!SFX_ON) return null;
  return (
    <Sequence from={Math.max(0, at)} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol} />
    </Sequence>
  );
};
