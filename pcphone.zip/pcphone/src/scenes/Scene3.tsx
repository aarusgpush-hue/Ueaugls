import React from "react";
import { AbsoluteFill, interpolate, spring } from "remotion";
import { theme, glass } from "../theme";
import { Entrance, SceneWrap, Sfx, WordReveal, ramp, useFloat, useT } from "../components/Motion";
import { Check } from "../components/Icons";

// Voiceover timing is estimated: tweak these (seconds, relative to scene start) to match your audio.
const GAMES = [
  { name: "GTA 5", at: 5.5 },
  { name: "GTA 6", at: 7.5 },
  { name: "Call of Duty", at: 9.5 },
];
const LIFT_AT = 4.2;

const Card: React.FC<{ name: string; at: number; i: number }> = ({ name, at, i }) => {
  const { frame, fps, s } = useT();
  const bar = spring({ frame: frame - s(at) - 10, fps, config: { damping: 24, stiffness: 70 } });
  const tick = ramp(frame, s(at) + 34, s(at) + 46);
  const fl = useFloat(5, 34, i * 25);
  return (
    <Entrance delay={s(at)} y={70} from={0.9} preset="smooth">
      <div style={{
        width: 540, padding: "38px 44px", borderRadius: 36, ...glass,
        display: "flex", flexDirection: "column", gap: 30, transform: `translateY(${fl}px)`,
      }}>
        <div style={{ fontFamily: theme.fonts.latin, fontWeight: 800, fontSize: 64, letterSpacing: "-0.03em", color: theme.colors.text }}>{name}</div>
        <div style={{ height: 14, borderRadius: 7, background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
          <div style={{ width: `${Math.min(1, bar) * 100}%`, height: "100%", borderRadius: 7, background: `linear-gradient(90deg, ${theme.colors.primary}, ${theme.colors.accent})` }} />
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 18, fontFamily: theme.fonts.display, fontWeight: 600, fontSize: 40, color: theme.colors.textDim }}>
          <Check size={52} progress={tick} />
          <span style={{ color: theme.colors.text }}>চলবে</span>
        </div>
      </div>
    </Entrance>
  );
};

export const Scene3: React.FC = () => {
  const { frame, s } = useT();
  const lift = ramp(frame, s(LIFT_AT), s(LIFT_AT + 1), theme.ease.inOut);
  return (
    <SceneWrap>
      <Sfx at={s(0.1)} name="whoosh" />
      <Sfx at={s(LIFT_AT)} name="whoosh" vol={0.4} />
      {GAMES.map((g) => <Sfx key={g.name} at={s(g.at) - 3} name="pop" vol={0.5} />)}
      <AbsoluteFill>
        <div style={{
          position: "absolute", left: 0, right: 0, top: interpolate(lift, [0, 1], [360, 130]),
          transform: `scale(${interpolate(lift, [0, 1], [1, 0.74])})`, display: "flex", justifyContent: "center",
        }}>
          <WordReveal text="সবথেকে হেভি গেম চলবে" delay={3} per={5} size={130} hl={[1]} />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 470, display: "flex", justifyContent: "center", gap: 44 }}>
          {GAMES.map((g, i) => <Card key={g.name} name={g.name} at={g.at} i={i} />)}
        </div>
      </AbsoluteFill>
    </SceneWrap>
  );
};
