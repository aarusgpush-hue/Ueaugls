import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { Chip, Entrance, HeroWord, SceneWrap, Sfx, WordReveal, ramp, useFloat, useT } from "../components/Motion";
import { Check, GamepadIcon, LaptopIcon } from "../components/Icons";

// "গেমিং করতে চান? → কম্পিউটার বা ল্যাপটপ"
export const Scene2: React.FC = () => {
  const { frame, s } = useT();
  const fl = useFloat(9, 30), fp = useFloat(7, 22, 15);
  const lit = ramp(frame, s(1.2), s(2.4));
  const tick = ramp(frame, s(3.6), s(4.3));
  return (
    <SceneWrap>
      <Sfx at={s(0.1)} name="whoosh" />
      <Sfx at={s(0.9) - 3} name="pop" />
      <Sfx at={s(2.2) - 3} name="pop" vol={0.5} />
      <Sfx at={s(3.6)} name="shimmer" vol={0.4} />
      <AbsoluteFill style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 100, paddingBottom: 150 }}>
        <div style={{ width: 800, display: "flex", flexDirection: "column", gap: 36, alignItems: "flex-start" }}>
          <Entrance delay={0} y={20}><Chip>গেমিং</Chip></Entrance>
          <WordReveal text="গেমিং করতে চান?" delay={5} per={5} size={112} align="flex-start" />
          <Entrance delay={s(2.2)} y={30}>
            <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
              <HeroWord delay={s(2.2)} size={80}>কম্পিউটার</HeroWord>
              <span style={{ fontFamily: theme.fonts.display, fontSize: 48, color: theme.colors.textDim }}>বা</span>
              <Chip size={52}>ল্যাপটপ</Chip>
              <Check size={72} progress={tick} />
            </div>
          </Entrance>
        </div>
        <div style={{ position: "relative", width: 700, height: 520 }}>
          <Entrance delay={s(0.4)} x={100} y={20} style={{ position: "absolute", left: 0, top: 40, transform: undefined }}>
            <div style={{ transform: `translateY(${fl}px)` }}><LaptopIcon width={680} lit={lit} id="s2l" /></div>
          </Entrance>
          <Entrance delay={s(0.9)} x={60} y={80} from={0.6} rotate={-18} preset="bouncy" style={{ position: "absolute", right: -30, bottom: 0 }}>
            <div style={{ transform: `translateY(${fp}px)`, filter: `drop-shadow(0 0 40px ${theme.colors.accent}66)` }}>
              <GamepadIcon width={300} />
            </div>
          </Entrance>
        </div>
      </AbsoluteFill>
    </SceneWrap>
  );
};
