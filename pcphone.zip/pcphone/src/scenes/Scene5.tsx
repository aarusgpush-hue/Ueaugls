import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { Chip, Entrance, HeroWord, SceneWrap, Sfx, WordReveal, ramp, useFloat, useT } from "../components/Motion";
import { Check, LaptopIcon } from "../components/Icons";

const P0 = { x: 140, y: 300 }, C = { x: 750, y: -70 }, P2 = { x: 1360, y: 300 };
const bez = (t: number) => ({
  x: (1 - t) ** 2 * P0.x + 2 * (1 - t) * t * C.x + t * t * P2.x,
  y: (1 - t) ** 2 * P0.y + 2 * (1 - t) * t * C.y + t * t * P2.y,
});

// "পকেট ফ্রেন্ডলি বা ট্রাভেলিং → ল্যাপটপ বেস্ট"
export const Scene5: React.FC = () => {
  const { frame, s } = useT();
  const t = ramp(frame, s(1.6), s(7), theme.ease.inOut);
  const pos = bez(t);
  const bob = useFloat(4, 9);
  const pulse = 1 + Math.sin(frame / 10) * 0.12;
  const tick = ramp(frame, s(9.4), s(10.2));
  return (
    <SceneWrap>
      <Sfx at={s(0.1)} name="whoosh" />
      <Sfx at={s(0.6) - 3} name="pop" vol={0.45} />
      <Sfx at={s(1.5)} name="whoosh" vol={0.35} />
      <Sfx at={s(8.6) - 3} name="pop" />
      <Sfx at={s(9.4)} name="shimmer" vol={0.4} />
      <AbsoluteFill>
        <div style={{ position: "absolute", top: 70, left: 0, right: 0 }}>
          <WordReveal text="পকেট ফ্রেন্ডলি বা ট্রাভেলিং?" delay={2} per={4} size={104} />
        </div>
        <div style={{ position: "absolute", top: 270, left: 210, width: 1500, height: 380 }}>
          <Entrance delay={s(0.6)} y={20} style={{ position: "absolute", left: 40, top: 300 }}><Chip>পকেট ফ্রেন্ডলি</Chip></Entrance>
          <Entrance delay={s(1.0)} y={20} style={{ position: "absolute", left: 1240, top: 300 }}><Chip>ট্রাভেলিং</Chip></Entrance>
          <svg width={1500} height={380} style={{ position: "absolute", inset: 0, overflow: "visible" }}>
            <path d={`M${P0.x} ${P0.y} Q${C.x} ${C.y} ${P2.x} ${P2.y}`} fill="none" stroke="rgba(255,255,255,0.22)" strokeWidth={4} strokeDasharray="4 18" strokeLinecap="round" />
            {[P0, P2].map((p, i) => (
              <g key={i}>
                <circle cx={p.x} cy={p.y} r={26 * pulse} fill={theme.colors.accent} opacity={0.2} />
                <circle cx={p.x} cy={p.y} r={11} fill={theme.colors.accent} />
              </g>
            ))}
          </svg>
          <div style={{ position: "absolute", left: pos.x - 130, top: pos.y - 150 + bob, opacity: ramp(frame, s(1.2), s(1.8)) }}>
            <LaptopIcon width={260} lit={1} id="s5l" />
          </div>
        </div>
        <div style={{ position: "absolute", top: 700, left: 0, right: 0, display: "flex", justifyContent: "center", alignItems: "center", gap: 36 }}>
          <WordReveal text="ল্যাপটপ" delay={s(8.2)} size={124} />
          <HeroWord delay={s(8.8)} size={124}>বেস্ট</HeroWord>
          <Check size={92} progress={tick} />
        </div>
      </AbsoluteFill>
    </SceneWrap>
  );
};
