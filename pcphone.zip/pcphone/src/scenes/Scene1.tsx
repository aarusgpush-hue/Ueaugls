import React from "react";
import { AbsoluteFill, interpolate, spring } from "remotion";
import { theme, toBn } from "../theme";
import { Chip, Entrance, SceneWrap, Sfx, WordReveal, useFloat, useT } from "../components/Motion";
import { LaptopIcon, PhoneIcon } from "../components/Icons";

// HOOK: "১ লাখ টাকার কম্পিউটার নাকি ফোন?"
export const Scene1: React.FC = () => {
  const { frame, fps, s } = useT();
  const fl1 = useFloat(10, 28), fl2 = useFloat(10, 28, 40);
  const budget = interpolate(spring({ frame: frame - s(1.6), fps, config: { damping: 30, stiffness: 60 } }), [0, 1], [0, 100000]);
  const vs = spring({ frame: frame - s(0.9), fps, config: theme.spring.bouncy });
  return (
    <SceneWrap>
      <Sfx at={s(0.2)} name="whoosh" />
      <Sfx at={s(0.9) - 3} name="pop" />
      <Sfx at={s(1.6) - 3} name="shimmer" vol={0.35} />
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", flexDirection: "column", gap: 40, paddingBottom: 150 }}>
        <WordReveal text="কম্পিউটার নাকি ফোন?" delay={2} per={5} size={140} />
        <div style={{ display: "flex", alignItems: "center", gap: 90, marginTop: 10 }}>
          <Entrance delay={s(0.3)} x={-140} y={20} preset="smooth">
            <div style={{ transform: `translateY(${fl1}px)` }}><LaptopIcon width={560} lit={0.9} id="s1l" /></div>
          </Entrance>
          <div style={{
            width: 132, height: 132, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center",
            background: theme.colors.primary, color: "#fff", fontFamily: theme.fonts.latin, fontWeight: 800, fontSize: 52,
            transform: `scale(${Math.max(0, vs)}) rotate(${interpolate(vs, [0, 1], [-90, 0])}deg)`,
            boxShadow: `0 0 70px ${theme.colors.primary}88, 0 0 140px ${theme.colors.primary}44`,
          }}>VS</div>
          <Entrance delay={s(0.5)} x={140} y={20} preset="smooth">
            <div style={{ transform: `translateY(${fl2}px)` }}><PhoneIcon height={400} id="s1p" /></div>
          </Entrance>
        </div>
        <Entrance delay={s(1.6)} y={30}>
          <Chip size={44}>
            <span style={{ color: theme.colors.textDim }}>বাজেট</span>
            <span style={{ fontVariantNumeric: "tabular-nums", fontWeight: 700 }}>{toBn(budget)}</span>
            <span>টাকা</span>
          </Chip>
        </Entrance>
      </AbsoluteFill>
    </SceneWrap>
  );
};
