import React from "react";
import { AbsoluteFill, interpolateColors, random } from "remotion";
import { theme, glass } from "../theme";
import { Chip, Entrance, SceneWrap, Sfx, WordReveal, ramp, useFloat, useT } from "../components/Motion";
import { Cross, PhoneIcon } from "../components/Icons";

// "ফোন হিট হয়ে যাবে বা সাপোর্ট করবে না"
export const Scene4: React.FC = () => {
  const { frame, s } = useT();
  const heat = ramp(frame, s(1.4), s(5.2), theme.ease.inOut);
  const shake = Math.sin(frame * 1.9) * 6 * heat * heat;
  const fl = useFloat(6, 30);
  const col = interpolateColors(heat, [0, 1], [theme.colors.accent, theme.colors.warn]);
  const stamp = ramp(frame, s(5.8), s(6.5));
  return (
    <SceneWrap>
      <Sfx at={s(0.1)} name="whoosh" />
      <Sfx at={s(0.6) - 3} name="pop" />
      <Sfx at={s(5.8) - 2} name="thud" vol={0.7} />
      <AbsoluteFill style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 150, paddingBottom: 150 }}>
        <Entrance delay={s(0.3)} x={-100} y={30}>
          <div style={{ position: "relative", transform: `translate(${shake}px, ${fl}px)` }}>
            <div style={{ position: "absolute", inset: -140, borderRadius: "50%", background: `radial-gradient(circle, ${theme.colors.warn}${Math.round(heat * 90).toString(16).padStart(2, "0")}, transparent 65%)` }} />
            {Array.from({ length: 8 }).map((_, i) => {
              const r = random(`heat${i}`);
              const y = (frame * (1.6 + r * 2) + r * 400) % 340;
              return <div key={i} style={{ position: "absolute", left: 40 + r * 180, top: -20 - y, width: 10 + r * 14, height: 10 + r * 14, borderRadius: "50%", background: theme.colors.warn, opacity: heat * (1 - y / 340) * 0.55, filter: "blur(5px)" }} />;
            })}
            <div style={{ position: "relative" }}><PhoneIcon height={560} heat={heat} id="s4p" /></div>
          </div>
        </Entrance>
        <div style={{ width: 860, display: "flex", flexDirection: "column", gap: 40, alignItems: "flex-start" }}>
          <WordReveal text="ফোন হিট হয়ে যাবে" delay={s(0.8)} per={5} size={104} align="flex-start" />
          <Entrance delay={s(1.2)} y={30} style={{ width: "100%" }}>
            <div style={{ ...glass, borderRadius: 32, padding: "30px 36px", display: "flex", flexDirection: "column", gap: 18 }}>
              <div style={{ height: 22, borderRadius: 11, background: "rgba(255,255,255,0.1)", overflow: "hidden" }}>
                <div style={{ width: `${(0.06 + heat * 0.94) * 100}%`, height: "100%", borderRadius: 11, background: `linear-gradient(90deg, ${theme.colors.accent}, ${col})`, boxShadow: `0 0 30px ${col}88` }} />
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontFamily: theme.fonts.latin, fontWeight: 600, fontSize: 26, color: theme.colors.textDim }}>
                <span>COOL</span><span style={{ color: col }}>HOT</span>
              </div>
            </div>
          </Entrance>
          <Entrance delay={s(5.8)} y={40} from={1.15} preset="bouncy">
            <div style={{ display: "flex", alignItems: "center", gap: 24 }}>
              <Cross size={84} progress={stamp} />
              <Chip size={58} hero>সাপোর্ট করবে না</Chip>
            </div>
          </Entrance>
        </div>
      </AbsoluteFill>
    </SceneWrap>
  );
};
