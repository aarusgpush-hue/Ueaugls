import React from "react";
import { AbsoluteFill, interpolate } from "remotion";
import { theme, glass } from "../theme";
import { Chip, Entrance, SceneWrap, Sfx, WordReveal, ramp, useFloat, useT } from "../components/Motion";
import { PhoneIcon } from "../components/Icons";

// Voiceover timing estimated: tweak (seconds, relative to scene start).
const BRANDS = [{ name: "Samsung", at: 6.5 }, { name: "Google Pixel", at: 9 }];
const LIFT_AT = 5, RECAP_AT = 14.5;
const RECAP = [
  { k: "গেমিং", v: "কম্পিউটার / ল্যাপটপ", latin: false },
  { k: "ট্রাভেলিং", v: "ল্যাপটপ", latin: false },
  { k: "ফোন", v: "Samsung / Google Pixel", latin: true },
];

const BrandCard: React.FC<{ name: string; at: number; i: number }> = ({ name, at, i }) => {
  const { s } = useT();
  const fl = useFloat(7, 30, i * 30);
  return (
    <Entrance delay={s(at)} y={70} from={0.9}>
      <div style={{ ...glass, borderRadius: 40, width: 520, padding: "36px 40px", display: "flex", alignItems: "center", gap: 36, transform: `translateY(${fl}px)` }}>
        <PhoneIcon height={230} id={`s6p${i}`} />
        <div style={{ fontFamily: theme.fonts.latin, fontWeight: 800, fontSize: 58, letterSpacing: "-0.03em", color: theme.colors.text, lineHeight: 1.1 }}>{name}</div>
      </div>
    </Entrance>
  );
};

export const Scene6: React.FC = () => {
  const { frame, s } = useT();
  const lift = ramp(frame, s(LIFT_AT), s(LIFT_AT + 1), theme.ease.inOut);
  const out = ramp(frame, s(RECAP_AT - 1), s(RECAP_AT - 0.6), theme.ease.in);
  return (
    <SceneWrap>
      <Sfx at={s(0.1)} name="whoosh" />
      <Sfx at={s(LIFT_AT)} name="whoosh" vol={0.4} />
      {BRANDS.map((b) => <Sfx key={b.name} at={s(b.at) - 3} name="pop" vol={0.5} />)}
      <Sfx at={s(RECAP_AT) - 3} name="whoosh" vol={0.5} />
      <Sfx at={s(RECAP_AT + 2.5)} name="shimmer" vol={0.4} />
      <AbsoluteFill style={{ opacity: 1 - out, transform: `translateY(${-40 * out}px)` }}>
        <div style={{ position: "absolute", left: 0, right: 0, top: interpolate(lift, [0, 1], [380, 150]), transform: `scale(${interpolate(lift, [0, 1], [1, 0.78])})` }}>
          <WordReveal text="ফোন কিনতেই হলে?" delay={3} per={5} size={140} hl={[0]} />
        </div>
        <div style={{ position: "absolute", left: 0, right: 0, top: 480, display: "flex", justifyContent: "center", gap: 60 }}>
          {BRANDS.map((b, i) => <BrandCard key={b.name} {...b} i={i} />)}
        </div>
      </AbsoluteFill>
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", paddingBottom: 150, gap: 28 }}>
        {RECAP.map((r, i) => (
          <Entrance key={r.k} delay={s(RECAP_AT) + i * 6} y={50} style={{ width: 1500 }}>
            <div style={{ ...glass, borderRadius: 36, padding: "28px 52px", display: "flex", alignItems: "center", gap: 40 }}>
              <div style={{ width: 360 }}><Chip size={40}>{r.k}</Chip></div>
              <span style={{ fontSize: 56, color: theme.colors.textDim }}>→</span>
              <div style={{ fontFamily: r.latin ? theme.fonts.latin : theme.fonts.display, fontWeight: 700, fontSize: 68, color: theme.colors.text }}>{r.v}</div>
            </div>
          </Entrance>
        ))}
      </AbsoluteFill>
    </SceneWrap>
  );
};
